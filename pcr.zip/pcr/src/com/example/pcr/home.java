package com.example.pcr;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class home extends Activity {

	ImageView homee,contact_us,about_us,complain,feedback,reply;
	 @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.home);
	        homee=(ImageView)findViewById(R.id.img1);
	        contact_us=(ImageView)findViewById(R.id.img2);
	        about_us=(ImageView)findViewById(R.id.img3);
	        complain=(ImageView)findViewById(R.id.img4);
	        feedback=(ImageView)findViewById(R.id.img5);
	        reply=(ImageView)findViewById(R.id.img6);
	        
	       complain.setOnClickListener(new OnClickListener() {
	    		
	    		@Override
	    		public void onClick(View arg0) {
	    			// TODO Auto-generated method stub
	    			 String a;
	    		     a=getIntent().getExtras().getString("Type").toString();
	    		     Intent i;
	    		     if(a.equals("GTPL"))
	    		     {
	    		    	 i=new Intent(home.this,complain_gtpl.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("BSNL"))
	    		     {
	    		    	i=new Intent(home.this,complain_bsnl.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("GWSSB"))
	    		     {
	    		    	i=new Intent(home.this,complain_gwssb.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("GSPC"))
	    		     {
	    		    	i=new Intent(home.this,complain_gspc.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("GEB"))
	    		     {
	    		    	i=new Intent(home.this,complain_geb.class);
	 	    			startActivity(i);
	    		     }
	    			
	    		}
	    	});
	       feedback.setOnClickListener(new OnClickListener() {
	    		
	    		@Override
	    		public void onClick(View arg0) {
	    			// TODO Auto-generated method stub
	    			 String a;
	    		     a=getIntent().getExtras().getString("Type").toString();
	    		     Intent i;
	    		     if(a.equals("GTPL"))
	    		     {
	    		    	 i=new Intent(home.this,feedback_gtpl.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("BSNL"))
	    		     {
	    		    	i=new Intent(home.this,feedback_bsnl.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("GWSSB"))
	    		     {
	    		    	i=new Intent(home.this,feedback_gwssb.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("GSPC"))
	    		     {
	    		    	i=new Intent(home.this,feedback_gspc.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("GEB"))
	    		     {
	    		    	i=new Intent(home.this,feedback_geb.class);
	 	    			startActivity(i);
	    		     }
	    			
	    			
	    		}
	    	});
	       
	       contact_us.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String a;
   		     	a=getIntent().getExtras().getString("Type").toString();
   		     	
   		     if(a.equals("GTPL"))
   		     {
				Intent intent = new Intent();
		        intent.setAction(Intent.ACTION_VIEW);
		        intent.addCategory(Intent.CATEGORY_BROWSABLE);
		        intent.setData(Uri.parse("http://www.gtpl.net/connect.html"));
		        startActivity(intent);
   		     }
   		     else if(a.equals("BSNL"))
   		     {
   		    	Intent intent = new Intent();
		        intent.setAction(Intent.ACTION_VIEW);
		        intent.addCategory(Intent.CATEGORY_BROWSABLE);
		        intent.setData(Uri.parse("http://www.bsnl.in/opencms/bsnl/BSNL/about_us/contact_us.html"));
		        startActivity(intent);
   		     }
   		     else if(a.equals("GWSSB"))
		     {
		    	Intent intent = new Intent();
		        intent.setAction(Intent.ACTION_VIEW);
		        intent.addCategory(Intent.CATEGORY_BROWSABLE);
		        intent.setData(Uri.parse("https://gwssb.gujarat.gov.in/contact"));
		        startActivity(intent);
		     }
   		     else if(a.equals("GSPC"))
   		  	{
   			  	Intent intent = new Intent();
   			  	intent.setAction(Intent.ACTION_VIEW);
   			  	intent.addCategory(Intent.CATEGORY_BROWSABLE);
   			  	intent.setData(Uri.parse("http://www.gspcgroup.com/contact-us"));
   			  	startActivity(intent);
   		  	}
   		     else if(a.equals("GEB"))
   		  	{
   			  	Intent intent = new Intent();
   			  	intent.setAction(Intent.ACTION_VIEW);
   			  	intent.addCategory(Intent.CATEGORY_BROWSABLE);
	        	intent.setData(Uri.parse("http://www.gseb.com/guvnl/Content.aspx?ContentId=10"));
	        	startActivity(intent);
   		  	}
			}
		});
	       
	       about_us.setOnClickListener(new OnClickListener() {
	    		
	    		@Override
	    		public void onClick(View arg0) {
	    			// TODO Auto-generated method stub
	    			 String a;
	    		     a=getIntent().getExtras().getString("Type").toString();
	    		     Intent i;
	    		     if(a.equals("GTPL"))
	    		     {
	    		    	 i=new Intent(home.this,aboutus_gtpl.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("BSNL"))
	    		     {
	    		    	i=new Intent(home.this,aboutus_bsnl.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("GWSSB"))
	    		     {
	    		    	i=new Intent(home.this,aboutus_gwssb.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("GSPC"))
	    		     {
	    		    	i=new Intent(home.this,aboutus_gspc.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("GEB"))
	    		     {
	    		    	i=new Intent(home.this,aboutus_geb.class);
	 	    			startActivity(i);
	    		     }
	    			
	    			
	    		}
	    	});
	       homee.setOnClickListener(new OnClickListener() {
	    		
	    		@Override
	    		public void onClick(View arg0) {
	    			// TODO Auto-generated method stub
	    			 String a;
	    		     a=getIntent().getExtras().getString("Type").toString();
	    		     Intent i;
	    		     if(a.equals("GTPL"))
	    		     {
	    		    	 i=new Intent(home.this,home_gtpl.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("BSNL"))
	    		     {
	    		    	 i=new Intent(home.this,home_bsnl.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("GWSSB"))
	    		     {
	    		    	 i=new Intent(home.this,home_gwssb.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("GSPC"))
	    		     {
	    		    	 i=new Intent(home.this,home_gspc.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("GEB"))
	    		     {
	    		    	 i=new Intent(home.this,home_geb.class);
	 	    			startActivity(i);
	    		     }
	    		}
	    		});
	       reply.setOnClickListener(new OnClickListener() {
	    		
	    		@Override
	    		public void onClick(View arg0) {
	    			// TODO Auto-generated method stub
	    			 String a;
	    		     a=getIntent().getExtras().getString("Type").toString();
	    		     Intent i;
	    		     if(a.equals("GTPL"))
	    		     {
	    		    	 i=new Intent(home.this,reply_gtpl.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("BSNL"))
	    		     {
	    		    	 i=new Intent(home.this,reply_bsnl.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("GWSSB"))
	    		     {
	    		    	 i=new Intent(home.this,reply_gwssb.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("GSPC"))
	    		     {
	    		    	 i=new Intent(home.this,reply_gspc.class);
	 	    			startActivity(i);
	    		     }
	    		     else if(a.equals("GEB"))
	    		     {
	    		    	 i=new Intent(home.this,reply_geb.class);
	 	    			startActivity(i);
	    		     }
	    		}
	    		});
}
}