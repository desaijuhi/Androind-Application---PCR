package com.example.pcr;





import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainpcrActivity extends Activity {

	ProgressBar p;
	TextView t;
	int ps=0;
	Handler handler=new Handler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainpcr);
        p=(ProgressBar)findViewById(R.id.pb1);
        t=(TextView)findViewById(R.id.tv1);
        new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				while(ps<10)
				{
					ps+=1;
					handler.post(new Runnable() {
									
						@Override
						public void run() {
							// TODO Auto-generated method stub
							p.setProgress(ps);
							//t.setText(String.valueOf(ps));
							if(ps==10)
							{
								
								Toast.makeText(getApplicationContext(), "progress complete", 1000).show();
								Intent i;
								i=new Intent(getApplicationContext(), login_pcr.class);
								startActivity(i);
							
							}
						}
						
					});
				try 
				{
					Thread.sleep(200);
					
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
				 
				}
			}
					
		}).start();
       
    }
   


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.mainpcr, menu);
        return true;
    }
    
}
