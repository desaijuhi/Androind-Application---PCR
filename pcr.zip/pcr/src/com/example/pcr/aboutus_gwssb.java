package com.example.pcr;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class aboutus_gwssb extends Activity {

	TextView t1,t2;
	ImageView i1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aboutus_gwssb);
        t1=(TextView)findViewById(R.id.tv1);
        t2=(TextView)findViewById(R.id.tv2);
        i1=(ImageView)findViewById(R.id.img1);

}
}