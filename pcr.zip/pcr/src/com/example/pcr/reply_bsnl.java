package com.example.pcr;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;


public class reply_bsnl extends ListActivity {

	// Progress Dialog
		private ProgressDialog pDialog;

		// php read comments script

		// localhost :
		// testing on your device
		// put your local ip instead, on windows, run CMD > ipconfig
		// or in mac's terminal type ifconfig and look for the ip under en0 or en1
		// private static final String READ_COMMENTS_URL =
		// "http://xxx.xxx.x.x:1234/webservice/comments.php";

		// testing on Emulator:
		//private static final String READ_COMMENTS_URL = "http://10.0.2.2/webservice/users.php";
		//private static final String READ_COMMENTS_URL = "http://10.0.2.2/webservice/reply_gtpl.php";
		private static final String READ_COMMENTS_URL = "http://192.168.13.1/webservice/reply_gtpl.php";
		// testing from a real server:
		// private static final String READ_COMMENTS_URL =
		// "http://www.mybringback.com/webservice/comments.php";
		  JSONParser jsonParser = new JSONParser();
		// JSON IDS:
		private static final String TAG_SUCCESS = "success";
		//private static final String TAG_TITLE = "Userid";
		private static final String TAG_POSTS = "posts";
		//private static final String TAG_POST_ID = "Userid";
		private static final String TAG_RPY = "Reply";
		//private static final String TAG_SUB = "Subject";
		// it's important to note that the message is both in the parent branch of
		// our JSON tree that displays a "Post Available" or a "No Post Available"
		// message,
		// and there is also a message for each individual post, listed under the
		// "posts"
		// category, that displays what the user typed as their message.

		// An array of all of our comments
		private JSONArray mComments = null;
		// manages all of our comments in a list.
		private ArrayList<HashMap<String, String>> mCommentList;
	
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			// note that use read_comments.xml instead of our single_post.xml
			setContentView(R.layout.reply_gtpl);
			
		}
		@Override
		protected void onResume() {
			// TODO Auto-generated method stub
			super.onResume();
			// loading the comments via AsyncTask
			new LoadComments().execute();
		}

		/*public void addComment(View v) {
			Intent i = new Intent(ReadUsers.this, AddComment.class);
			startActivity(i);
		}*/

		/**
		 * Retrieves recent post data from the server.
		 */
		public void updateJSONdata() {

			// Instantiate the arraylist to contain all the JSON data.
			// we are going to use a bunch of key-value pairs, referring
			// to the json element name, and the content, for example,
			// message it the tag, and "I'm awesome" as the content..
			SharedPreferences settings = getSharedPreferences(login_pcr.PREFS_NAME, MODE_PRIVATE);
	        String value = settings.getString("Userid", "");
	        Log.d("Userid", value);

			try {


			int success;
			
			List<NameValuePair> params = new ArrayList<NameValuePair>();
	        params.add(new BasicNameValuePair("Userid", value));
	      
	        Log.d("request!", "starting");
	        
	        JSONObject json = jsonParser.makeHttpRequest(
	        		READ_COMMENTS_URL, "POST", params);

	        // full json response
	        Log.d("Post Comment attempt", json.toString());

	        // json success element
	       
	        success = json.getInt(TAG_SUCCESS);
	        if (success == 1) {
			mCommentList = new ArrayList<HashMap<String, String>>();

			// Bro, it's time to power up the J parser
			JSONParser jParser = new JSONParser();
			// Feed the beast our comments url, and it spits us
			// back a JSON object. Boo-yeah Jerome.
			JSONObject json1 = jParser.getJSONFromUrl(READ_COMMENTS_URL);

			// when parsing JSON stuff, we should probably
			// try to catch any exceptions:
						// I know I said we would check if "Posts were Avail." (success==1)
				// before we tried to read the individual posts, but I lied...
				// mComments will tell us how many "posts" or comments are
				// available
				mComments = json.getJSONArray(TAG_POSTS);
				 
				// String un=getIntent().getExtras().getString("un").toString();
				// Toast.makeText(getApplicationContext(), un, 3000).show();
				// looping through all posts according to the json object returned
				for (int i = 0; i < mComments.length(); i++) {
					JSONObject c = mComments.getJSONObject(i);

					// gets the content of each tag
					//String user = c.getString(TAG_POST_ID);
					//String subj = c.getString(TAG_SUB);
					String reply = c.getString(TAG_RPY);

					// creating new HashMap
					HashMap<String, String> map = new HashMap<String, String>();

					//map.put(TAG_POST_ID, user);
					//map.put(TAG_SUB, subj);
					map.put(TAG_RPY, reply);

					// adding HashList to ArrayList
					mCommentList.add(map);

					// annndddd, our JSON data is up to date same with our array
					// list
					Log.d("Comment Added!", json.toString());    
	            	//finish();
	            	//return json.getString(TAG_MESSAGE);
	            }
	        }else{
	            	Log.d("Comment Failure!", json.getString(TAG_RPY));
	            //	return json.getString(TAG_MESSAGE);
				}
				
				}

			 catch (JSONException e) {
				e.printStackTrace();
			}
		}

		/**
		 * Inserts the parsed data into the listview.
		 */
		private void updateList() {
			// For a ListActivity we need to set the List Adapter, and in order to do
			//that, we need to create a ListAdapter.  This SimpleAdapter,
			//will utilize our updated Hashmapped ArrayList, 
			//use our single_post xml template for each item in our list,
			//and place the appropriate info from the list to the
			//correct GUI id.  Order is important here.
			ListAdapter adapter = new SimpleAdapter(this, mCommentList,
					R.layout.single_post5, new String[] { 
							TAG_RPY }, new int[] {
							R.id.reply });

			// I shouldn't have to comment on this one:
			setListAdapter(adapter);
			
			// Optional: when the user clicks a list item we 
			//could do something.  However, we will choose
			//to do nothing...
			ListView lv = getListView();	
			lv.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {

					// This method is triggered if an item is click within our
					// list. For our example we won't be using this, but
					// it is useful to know in real life applications.

				}
			});
		}

		public class LoadComments extends AsyncTask<Void, Void, Boolean> {

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				pDialog = new ProgressDialog(reply_bsnl.this);
				pDialog.setMessage("Loading Logs...");
				pDialog.setIndeterminate(false);
				pDialog.setCancelable(true);
				pDialog.show();
			}

			@Override
			protected Boolean doInBackground(Void... arg0) {
				updateJSONdata();
				return null;

			}

			@Override
			protected void onPostExecute(Boolean result) {
				super.onPostExecute(result);
				pDialog.dismiss();
				updateList();
			}
		}
}
