package com.example.pcr;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;




import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class register_pcr extends Activity implements OnClickListener{

	private EditText e1, e2,e3,e4;
	private Button  b1;
	ImageView i1;
	 // Progress Dialog
    private ProgressDialog pDialog;
 
    // JSON parser class
    JSONParser jsonParser = new JSONParser();
    
    //php register script
    
    //localhost :  
    //testing on your device
    //put your local ip instead,  on windows, run CMD > ipconfig
    //or in mac's terminal type ifconfig and look for the ip under en0 or en1
   // private static final String REGISTER_URL = "http://xxx.xxx.x.x:1234/webservice/register.php";
    
    //testing on Emulator:
    //private static final String REGISTER_URL = "http://10.0.2.2/webservice/register_pcr.php";
    private static final String REGISTER_URL = "http://192.168.13.1/webservice/register_pcr.php";
    
  //testing from a real server:
    //private static final String REGISTER_URL = "http://www.mybringback.com/webservice/register.php";
    
    //ids
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";
    
    @Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register_pcr);
		
		e1 = (EditText)findViewById(R.id.et1);
		e2 = (EditText)findViewById(R.id.et2);
		e3 = (EditText)findViewById(R.id.et3);
		
		e4 = (EditText)findViewById(R.id.et4);
		i1 = (ImageView)findViewById(R.id.imageView1);

		b1 = (Button)findViewById(R.id.btn1);
		b1.setOnClickListener(this);
		
	}
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		int flag=0;
		final String userid = e3.getText().toString();
		final String pass = e4.getText().toString();
		if (!isValidEmail(userid)) {
			e3.setError("Invalid Email");
			flag=1;
			
		}
		if (!isValidPassword(pass)) {
			e4.setError("Invalid password");
			flag=1;
		}
		if(flag==0)
		{
		new CreateUser().execute();
		}
	}
	private boolean isValidEmail(String email) {
		String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

		Pattern pattern = Pattern.compile(EMAIL_PATTERN);
		Matcher matcher = pattern.matcher(email);
		return matcher.matches();
	}
	private boolean isValidPassword(String pass) {
		final String PASSWORD_PATTERN = 
	              "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
		Pattern pattern = Pattern.compile(PASSWORD_PATTERN);
		Matcher matcher = pattern.matcher(pass);
		return matcher.matches();
	}

class CreateUser extends AsyncTask<String, String, String> {

	
	@Override
    protected void onPreExecute() {
        super.onPreExecute();
        pDialog = new ProgressDialog(register_pcr.this);
        pDialog.setMessage("Creating User...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(true);
        pDialog.show();
    }
	
	
	@Override
	protected String doInBackground(String... args) {
		// TODO Auto-generated method stub
		 // Check for success tag
        int success;
        String fname = e1.getText().toString();
        String lname = e2.getText().toString();
        String userid = e3.getText().toString();

        String pass = e4.getText().toString();
        
        try {
            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("Firstname", fname));
            params.add(new BasicNameValuePair("Lastname", lname));
            params.add(new BasicNameValuePair("Userid", userid));
            params.add(new BasicNameValuePair("Password", pass));

            Log.d("request!", "starting");
            
            //Posting user data to script 
            JSONObject json = jsonParser.makeHttpRequest(
                   REGISTER_URL, "POST", params);

            // full json response
            Log.d("Registering attempt", json.toString());

            // json success element
            success = json.getInt(TAG_SUCCESS);
            if (success == 1) {
            	Log.d("User Created!", json.toString());              	
            	finish();
            	return json.getString(TAG_MESSAGE);
            }else{
            	Log.d("Registering Failure!", json.getString(TAG_MESSAGE));
            	return json.getString(TAG_MESSAGE);
            	
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
		
	}
	
    protected void onPostExecute(String file_url) {
        // dismiss the dialog once product deleted
        pDialog.dismiss();
        if (file_url != null){
        	Toast.makeText(register_pcr.this, file_url, Toast.LENGTH_LONG).show();
        }

    }
	

}
}