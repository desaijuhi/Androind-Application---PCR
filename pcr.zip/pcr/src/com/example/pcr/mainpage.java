package com.example.pcr;



import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.Toast;

public class mainpage extends Activity{
	
	ImageView gtpl,bsnl,gwssb,gspc,geb;
	public static final String PREFS_NAME = "MyApp_Settings";
	 @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.mainpage);
	        gtpl=(ImageView)findViewById(R.id.img1);
	        bsnl=(ImageView)findViewById(R.id.img2);
	        gwssb=(ImageView)findViewById(R.id.img3);
	        gspc=(ImageView)findViewById(R.id.img4);
	        geb=(ImageView)findViewById(R.id.img5);
	        SharedPreferences settings = getSharedPreferences(login_pcr.PREFS_NAME, MODE_PRIVATE);
	        String value = settings.getString("Userid", "");
	        Log.d("Userid", value);
	       
	        Toast.makeText(getApplicationContext(),String.valueOf(value) , Toast.LENGTH_LONG).show();
	gtpl.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			Intent i;
			i=new Intent(mainpage.this,home.class);
			i.putExtra("Type","GTPL");
			startActivity(i);
		}
	});
	
	bsnl.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			Intent i;
			i=new Intent(mainpage.this,home.class);
			i.putExtra("Type","BSNL");
			startActivity(i);
		}
	});
	gwssb.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			Intent i;
			i=new Intent(mainpage.this,home.class);
			i.putExtra("Type","GWSSB");
			startActivity(i);
		}
	});
	gspc.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			Intent i;
			i=new Intent(mainpage.this,home.class);
			i.putExtra("Type","GSPC");
			startActivity(i);
		}
	});
	geb.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			Intent i;
			i=new Intent(mainpage.this,home.class);
			i.putExtra("Type","GEB");
			startActivity(i);
		}
	});
}
	
	private SharedPreferences getSharedPreferences(mainpage mainpage,
			int modePrivate) {
		// TODO Auto-generated method stub
		return null;
	}
}