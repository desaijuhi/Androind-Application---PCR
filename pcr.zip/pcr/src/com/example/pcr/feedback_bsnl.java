package com.example.pcr;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;



public class feedback_bsnl extends Activity{

	EditText e1,e2;
	Button b1;
	Spinner s1;
	ImageView i1;
	TextView t1;
	// JSON parser class
    JSONParser jsonParser = new JSONParser();
    
    //php register script
    
    //localhost :  
    //testing on your device
    //put your local ip instead,  on windows, run CMD > ipconfig
    //or in mac's terminal type ifconfig and look for the ip under en0 or en1
   // private static final String REGISTER_URL = "http://xxx.xxx.x.x:1234/webservice/register.php";
    
    //testing on Emulator:
    //private static final String FEEDBACK_URL = "http://10.0.2.2/webservice/feedback_bsnl.php";
    private static final String FEEDBACK_URL = "http://192.168.13.1/webservice/feedback_bsnl.php";
    
  //testing from a real server:
    //private static final String REGISTER_URL = "http://www.mybringback.com/webservice/register.php";
    
    //ids
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feedback_bsnl);
        e1=(EditText)findViewById(R.id.et1);
        b1=(Button)findViewById(R.id.btn1);
        s1=(Spinner)findViewById(R.id.sp1);
        i1=(ImageView)findViewById(R.id.img1);
        t1=(TextView)findViewById(R.id.tv1);
        b1.setOnClickListener(new OnClickListener() {
        	
        	@Override
        	public void onClick(View arg0) {
        		// TODO Auto-generated method stub
        		
        		new CreateUser().execute();
        	}
        });
            }

class CreateUser extends AsyncTask<String, String, String> {

		
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
		
		@Override
		protected String doInBackground(String... args) {
			// TODO Auto-generated method stub
			 // Check for success tag
            int success;
            SharedPreferences settings = getSharedPreferences(login_pcr.PREFS_NAME, MODE_PRIVATE);
            String value = settings.getString("Userid", "");
            Log.d("Userid", value);
            String feedbak = e1.getText().toString();
            String sub=s1.getSelectedItem().toString();
            
           
            try {
                // Building Parameters
                List<NameValuePair> params = new ArrayList<NameValuePair>();
                params.add(new BasicNameValuePair("Userid", value));
                params.add(new BasicNameValuePair("Subject", sub));
                params.add(new BasicNameValuePair("Feedback", feedbak));
                
                
                Log.d("request!", "starting");
                
                //Posting user data to script 
                JSONObject json = jsonParser.makeHttpRequest(
                       FEEDBACK_URL, "POST", params);
 
                // full json response
                Log.d("Feedbacking attempt", json.toString());
 
                // json success element
                success = json.getInt(TAG_SUCCESS);
                if (success == 1) {
                	Log.d("feedback has been sent successfully!", json.toString()); 
                	Intent i;
                	i=new Intent(feedback_bsnl.this,fetch_feedback_bsnl.class);
                	startActivity(i);
                	//Toast.makeText(getApplicationContext(), "feedback has been sent successfully!", 2000).show();
                	finish();
                	return json.getString(TAG_MESSAGE);
                }else{
                	Log.d("Feedbacking Failure!", json.getString(TAG_MESSAGE));
                	return json.getString(TAG_MESSAGE);
                	
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
 
            return null;
			
		}
		
		protected void onPostExecute(String file_url) {
	            // dismiss the dialog once product deleted
	            if (file_url != null){
	            	Toast.makeText(feedback_bsnl.this, file_url, Toast.LENGTH_LONG).show();
	            }
	 
	        }
			
		}

}
