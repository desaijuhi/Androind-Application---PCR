package com.example.pcr;


import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.pcr.complain_gspc.CreateUser;



import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class complain_gtpl extends Activity {

	EditText e1,e2,e3;
	Button b1;
	Spinner s1,s2;
	ImageView i1;
	TextView t1;
	// JSON parser class
    JSONParser jsonParser = new JSONParser();
    
    //php register script
    
    //localhost :  
    //testing on your device
    //put your local ip instead,  on windows, run CMD > ipconfig
    //or in mac's terminal type ifconfig and look for the ip under en0 or en1
   // private static final String REGISTER_URL = "http://xxx.xxx.x.x:1234/webservice/register.php";
    
    //testing on Emulator:
    //private static final String COMPLAIN_URL = "http://10.0.2.2/webservice/complain_gtpl.php";
    private static final String COMPLAIN_URL = "http://192.168.13.1/webservice/complain_gtpl.php";
    
  //testing from a real server:
    //private static final String REGISTER_URL = "http://www.mybringback.com/webservice/register.php";
    
    //ids
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.complain_gtpl);
        e1=(EditText)findViewById(R.id.et1);
        e2=(EditText)findViewById(R.id.et2);
        e3=(EditText)findViewById(R.id.et3);
        t1=(TextView)findViewById(R.id.tv1);
        b1=(Button)findViewById(R.id.btn1);
        s1=(Spinner)findViewById(R.id.sp1);
        s2=(Spinner)findViewById(R.id.sp2);
        i1=(ImageView)findViewById(R.id.img1);
        
        
        b1.setOnClickListener(new OnClickListener() {
        	
        	@Override
        	public void onClick(View arg0) {
        		// TODO Auto-generated method stub
        		
        		final String ph_no = e3.getText().toString();
        		if (!isValidPhone_no(ph_no)) {
        			e3.setError("Invalid Phone");
        		}
        		else
        		{
        		new CreateUser().execute();
        		}
        	}
        });
            }
    
    private boolean isValidPhone_no(String ph_no) {
		String PHONE_PATTERN = "^[+]?[0-9]{10,13}$";

		Pattern pattern = Pattern.compile(PHONE_PATTERN);
		Matcher matcher = pattern.matcher(ph_no);
		return matcher.matches();
	}

class CreateUser extends AsyncTask<String, String, String> {

	
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }
	
	@Override
	protected String doInBackground(String... args) {
		// TODO Auto-generated method stub
		 // Check for success tag
        int success;
        SharedPreferences settings = getSharedPreferences(login_pcr.PREFS_NAME, MODE_PRIVATE);
        String value = settings.getString("Userid", "");
        Log.d("Userid", value);
        String prob = e1.getText().toString();
        String add = e2.getText().toString();
        String ph_no = e3.getText().toString();
        String sub=s1.getSelectedItem().toString();
        String city=s2.getSelectedItem().toString();
        
       
        try {
            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("Userid", value));
            params.add(new BasicNameValuePair("Subject", sub));
            params.add(new BasicNameValuePair("Problem", prob));
            params.add(new BasicNameValuePair("City", city));
            params.add(new BasicNameValuePair("Address", add));
            params.add(new BasicNameValuePair("Phone_no", ph_no));
            
            Log.d("request!", "starting");
            
            //Posting user data to script 
            JSONObject json = jsonParser.makeHttpRequest(
                   COMPLAIN_URL, "POST", params);

            // full json response
            Log.d("Complaining attempt", json.toString());

            // json success element
            success = json.getInt(TAG_SUCCESS);
            if (success == 1) {
            	Log.d("complain has been sent successfully!", json.toString());    
            	Intent i;
            	i=new Intent(complain_gtpl.this,fetch_complain_gtpl.class);
            	startActivity(i);
            	//Toast.makeText(getApplicationContext(), "feedback has been sent successfully!", 2000).show();
            	finish();
            	return json.getString(TAG_MESSAGE);
            }else{
            	Log.d("Complaining Failure!", json.getString(TAG_MESSAGE));
            	return json.getString(TAG_MESSAGE);
            	
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
		
	}
	
	protected void onPostExecute(String file_url) {
            // dismiss the dialog once product deleted
            if (file_url != null){
            	Toast.makeText(complain_gtpl.this, file_url, Toast.LENGTH_LONG).show();
            }
 
        }
		
	}

}
